Dado('que acesso o site da Casas Bahia') do
    visit 'https://www.casasbahia.com.br/'
end
  
Quando('pesquisei a televisao {string}') do |opcao01|

end 

Quando('clicar no produto desejado') do 

end 

Entao('validar que o produto foi adicionado ao carrinho') do 

end 